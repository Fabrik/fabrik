<?php
$d             = $displayData;

?>

<div id="<?php echo $d->id; ?>" class="fabrikinput">
	<?php echo $d->value;?>
</div>